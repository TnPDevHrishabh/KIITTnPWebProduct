package com.kiit_tnp.api.noticeService.NoticeServer.Models;

public class ConnectorMessage {

	private String message;

	public ConnectorMessage(String message) {
		super();
		this.message = message;
	}
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}
