package com.kiit_tnp.api.noticeService.NoticeServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NoticeServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(NoticeServerApplication.class, args);
	}
}
