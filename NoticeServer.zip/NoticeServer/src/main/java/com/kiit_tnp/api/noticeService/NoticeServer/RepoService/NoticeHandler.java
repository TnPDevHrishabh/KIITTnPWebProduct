package com.kiit_tnp.api.noticeService.NoticeServer.RepoService;

import com.kiit_tnp.api.noticeService.NoticeServer.Models.NoticeModel;
import com.kiit_tnp.api.noticeService.NoticeServer.Repository.NoticeRepository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class NoticeHandler {
    
    @Autowired
    private NoticeRepository noticeRepo;
    
    public List<NoticeModel> getNotices(){
        
        List<NoticeModel> notices = new ArrayList<>();
        for(NoticeModel nm : noticeRepo.findAll()){
            notices.add(nm);
        }
        return notices;
    }
}
