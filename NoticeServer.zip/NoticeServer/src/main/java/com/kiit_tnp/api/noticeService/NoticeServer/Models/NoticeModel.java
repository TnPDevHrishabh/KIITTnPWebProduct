package com.kiit_tnp.api.noticeService.NoticeServer.Models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_notice")
public class NoticeModel{
	
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "notice_id")
    private long n_id;
    
    @Column(name = "start_date")
    private String st_dt;
    
    @Column(name = "end_date")
    private String en_dt;
    
    @Column(name = "content")
    private String bd;
    
    @Column(name = "notice_file")
    private String link;
    
    @Column(name = "class")
    private String cls;
    
    @Column(name = "heading")
    private String heading;
    
    @Column(name = "status")
    private String status;

    public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getHeading() {
		return heading;
	}

	public void setHeading(String heading) {
		this.heading = heading;
	}

	public long getN_id() {
        return n_id;
    }

    public void setN_id(long n_id) {
        this.n_id = n_id;
    }

    public String getSt_dt() {
        return st_dt;
    }

    public void setSt_dt(String st_dt) {
        this.st_dt = st_dt;
    }

    public String getEn_dt() {
        return en_dt;
    }

    public void setEn_dt(String en_dt) {
        this.en_dt = en_dt;
    }

    public String getBd() {
        return bd;
    }

    public void setBd(String bd) {
        this.bd = bd;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getCls() {
        return cls;
    }

    public void setCls(String cls) {
        this.cls = cls;
    }
}
