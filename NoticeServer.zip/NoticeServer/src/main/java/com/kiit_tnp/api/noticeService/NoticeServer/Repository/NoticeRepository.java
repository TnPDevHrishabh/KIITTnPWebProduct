
package com.kiit_tnp.api.noticeService.NoticeServer.Repository;

import com.kiit_tnp.api.noticeService.NoticeServer.Models.NoticeModel;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

@Component
//public interface NoticeRepository extends CrudRepository<NoticeModel,long>{
public interface NoticeRepository extends CrudRepository<NoticeModel , Long>{
    
}
