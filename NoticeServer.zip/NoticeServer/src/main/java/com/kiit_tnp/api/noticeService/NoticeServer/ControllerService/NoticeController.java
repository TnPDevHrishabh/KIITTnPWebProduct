package com.kiit_tnp.api.noticeService.NoticeServer.ControllerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.kiit_tnp.api.noticeService.NoticeServer.RepoService.ServiceStatusConfig;
import com.kiit_tnp.api.noticeService.NoticeServer.RepoService.SessionConnector;

@RestController
public class NoticeController {
    
    @Autowired
    private SessionConnector connector;
    
    @Autowired
    private ServiceStatusConfig serviceStatusConfig;
    
//    @Autowired
//    private NoticeHandler noticeHandle;
    
    @CrossOrigin(maxAge = 3600)
    @RequestMapping(value = "/api/2.1/notices",method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public Object retrieveNotices(@RequestHeader(value="RollNo") String roll){
    	
    	return connector.noticeRetriever(roll);
    }
    
//    @CrossOrigin(maxAge = 3600)
//    @RequestMapping(value = "/api/2.1/notices")
//    public List<NoticeModel> retrieveNotices(){
//    	
//    	return noticeHandle.getNotices();
//    }
    
    @RequestMapping(value = { "api/2.1/noticeservice/status" }, method = RequestMethod.GET)
	public Object getStatus() {				
		return serviceStatusConfig.getServiceStatus();
	
	}
}
