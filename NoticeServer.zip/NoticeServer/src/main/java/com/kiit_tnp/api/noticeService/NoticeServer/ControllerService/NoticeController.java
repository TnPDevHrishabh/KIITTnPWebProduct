package com.kiit_tnp.api.noticeService.NoticeServer.ControllerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.kiit_tnp.api.noticeService.NoticeServer.Models.ServiceInternalError;
import com.kiit_tnp.api.noticeService.NoticeServer.RepoService.ServiceStatusConfig;
import com.kiit_tnp.api.noticeService.NoticeServer.RepoService.SessionConnector;

@RestController
public class NoticeController {
	
	private static final String noticeKey = "2bda4b6a-2d91-4ece-8a20-55296cea2d12";

	@Autowired
	private SessionConnector connector;

	@Autowired
	private ServiceStatusConfig serviceStatusConfig;
	
	@Autowired
	private ServiceInternalError error;

	@RequestMapping(value = "/api/2.1/notices", method = RequestMethod.GET)
	public Object retrieveNotices(@RequestHeader(value = "RequestFromUI_Roll") String roll,
			@RequestHeader(value = "RequestFromUI_Session_1") String userSession1,
			@RequestHeader(value = "RequestFromUI_Session_2") String userSession2,
			@RequestHeader(value = "MasterKey") String key) {
		
		if(key.equals(noticeKey)) {
			return connector.noticeRetriever(roll, userSession1, userSession2);
		}
		else {
			error = new ServiceInternalError("{Warning : Unauthorized Request}");
			return error;
		}
	}

	@RequestMapping(value = { "api/2.1/noticeservice/status" }, method = RequestMethod.GET)
	public Object getStatus() {
		return serviceStatusConfig.getServiceStatus();

	}
}
