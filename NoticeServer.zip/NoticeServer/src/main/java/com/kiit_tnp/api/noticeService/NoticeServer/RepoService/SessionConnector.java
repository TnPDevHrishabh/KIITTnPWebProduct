package com.kiit_tnp.api.noticeService.NoticeServer.RepoService;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import com.kiit_tnp.api.noticeService.NoticeServer.Models.NoticeModel;
import com.kiit_tnp.api.noticeService.NoticeServer.Models.ConnectorMessage;

@Component
public class SessionConnector {

    @Autowired
    private NoticeHandler noticeHandle;
	
	public Object noticeRetriever(String roll) {
		
		String message = getSessionManagerStatus(roll);
    	List<NoticeModel> notices = new ArrayList<>();
    	if(message.equals("Access Granted")) {
    		notices = noticeHandle.getNotices();
    		return notices;
    	}
    	else {
    		ConnectorMessage obj = new ConnectorMessage(message);
    		return obj;
    	}
	}
	
	private String getSessionManagerStatus(String roll) {
		
		RestTemplate restTemplate = new RestTemplate();
    	String url = "http://localhost:7777/api/2.2/session/notice";
    	HttpHeaders header = new HttpHeaders();
    	header.add("id", roll);
    	HttpEntity<String> entity = new HttpEntity<String>(header);
    	ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
    	return response.getBody().toString();
	}

}
