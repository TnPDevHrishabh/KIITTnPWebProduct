package com.kiit_tnp.api.noticeService.NoticeServer.RepoService;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import com.kiit_tnp.api.noticeService.NoticeServer.Models.NoticeModel;
import com.kiit_tnp.api.noticeService.NoticeServer.Models.ConnectorMessage;

@Component
public class SessionConnector {
	
	private static final String url = "http://localhost:7777/api/2.2/session/notice";

    @Autowired
    private NoticeHandler noticeHandle;
	
	public Object noticeRetriever(String roll,String userSession1,String userSession2) {
		
		String message = getSessionManagerStatus(roll,userSession1,userSession2);
    	List<NoticeModel> notices = new ArrayList<>();
    	if(message.equals("Access Granted")) {
    		notices = noticeHandle.getNotices();
    		return notices;
    	}
    	else {
    		ConnectorMessage obj = new ConnectorMessage(message);
    		return obj;
    	}
	}
	
	private String getSessionManagerStatus(String roll,String userSession1,String userSession2) {
		
		RestTemplate restTemplate = new RestTemplate();
    	HttpHeaders header = new HttpHeaders();
    	header.add("userSession1", userSession1);
    	header.add("userSession2", userSession2);
    	header.add("id", roll);
    	HttpEntity<String> entity = new HttpEntity<String>(header);
    	ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
    	return response.getBody().toString();
	}

}
