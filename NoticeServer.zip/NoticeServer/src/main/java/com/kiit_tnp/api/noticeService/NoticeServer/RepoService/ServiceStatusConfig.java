package com.kiit_tnp.api.noticeService.NoticeServer.RepoService;

import org.springframework.stereotype.Component;

import com.kiit_tnp.api.noticeService.NoticeServer.Models.ServiceStatus;

@Component
public class ServiceStatusConfig {
	
	public ServiceStatus getServiceStatus() {
		
		return new ServiceStatus("running");
	}

}
