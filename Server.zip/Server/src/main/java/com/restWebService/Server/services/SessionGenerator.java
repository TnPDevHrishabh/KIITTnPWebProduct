package com.restWebService.Server.services;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Component;

@Component
public class SessionGenerator {
    
    private HttpSession session;
    
    public String getSession(HttpServletRequest request){
    
        String message="";
            String sessionId = retrieveSession(request);
            message = sessionId;
        return message;
    }
    
    private String retrieveSession(HttpServletRequest req){
        
        session = req.getSession();
        String sessionid = session.getId();
        //long CreationTime = session.getCreationTime();
        return sessionid;
    }
    
}
