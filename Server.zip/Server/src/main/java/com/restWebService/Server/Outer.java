package com.restWebService.Server;

public class Outer {

	public int x = 20;
	
	public class Inner{
		public int x = 10;
		
		public void show() {
			System.out.println(Outer.this.x);
		}
	}
}
