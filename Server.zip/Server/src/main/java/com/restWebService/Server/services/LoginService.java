
package com.restWebService.Server.services;

import com.restWebService.Server.crudRepo.MainRepo;
import com.restWebService.Server.models.LoginTable;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ModelAttribute;

@Component
public class LoginService {
    
    @Autowired
    private MainRepo repo;
    
    public List<LoginTable> retrieve(){
        List<LoginTable> stuff = new ArrayList<>();
        for(LoginTable t : repo.findAll()){
            stuff.add(t);
        }
        return stuff;
    }
    public void saveNew(@ModelAttribute LoginTable nl){
        repo.save(nl);
    }
    
    public void delete(String id){
        repo.delete(id);
    }
    
    public LoginTable update(String id){
        LoginTable ne = repo.findOne(id);
        return ne;
    }
    
}
