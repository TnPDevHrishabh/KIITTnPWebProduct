
package com.restWebService.Server.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name = "user_login")
public class LoginTable{
    @Id
    @Column(name = "roll_no")
    private String rn;
    
    @Column(name = "email_id")
    private String email;
    
    @Column(name = "password")
    private String pass;

    public String getRn() {
        return rn;
    }

    public void setRn(String rn) {
        this.rn = rn;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
    
    
}
