package com.restWebService.Server;

import java.util.UUID;

public class Masti {

	public static void main(String[] args) {
		
		System.out.println(UUID.randomUUID().toString());

	}

}
