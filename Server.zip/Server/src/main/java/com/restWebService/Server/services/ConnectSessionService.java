package com.restWebService.Server.services;

import com.restWebService.Server.models.UserSession;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class ConnectSessionService {
    
	private static final String url = "http://localhost:7777/api/2.2/session/new";
	
    public int connectToSessionService(UserSession mixedObject){
        
        String session = mixedObject.getUserSession();
        String rollNo = mixedObject.getUserId();
        return connect(rollNo, session).getStatusCodeValue();
    }
    
    private ResponseEntity<String> connect(String uId, String session) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.add("userSession", session);
        headers.add("userId", uId);
        HttpEntity<String> request = new HttpEntity<String>(headers);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, request, String.class);
        return response;
    }
}
