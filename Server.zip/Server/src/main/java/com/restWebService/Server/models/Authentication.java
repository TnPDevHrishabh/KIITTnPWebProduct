
package com.restWebService.Server.models;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class Authentication {
    
    private String status;
    private String response;
    private String message;
    private HttpStatus httpStatus;
    private String sessionId;
    private String rollNo;

    public Authentication() {
        
    }
    
    public Authentication(String status, String response, String message, HttpStatus httpStatus, String sessionId,String rollNo) {
        this.status = status;
        this.response = response;
        this.message = message;
        this.httpStatus = httpStatus;
        this.sessionId = sessionId;
        this.rollNo = rollNo;
    }
    
     public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }
    
     public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    public void setHttpStatus(HttpStatus httpStatus) {
        this.httpStatus = httpStatus;
    }
    
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

	public String getRollNo() {
		return rollNo;
	}

	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}
    
}
