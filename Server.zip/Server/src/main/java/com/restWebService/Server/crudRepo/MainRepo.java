
package com.restWebService.Server.crudRepo;

import com.restWebService.Server.models.LoginTable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

@Component
public interface MainRepo extends CrudRepository<LoginTable , String>{
    
}
