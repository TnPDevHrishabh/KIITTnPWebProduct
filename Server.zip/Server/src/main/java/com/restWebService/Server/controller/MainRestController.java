package com.restWebService.Server.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.restWebService.Server.config.AuthConfiguration;
import com.restWebService.Server.models.LoginTable;
import com.restWebService.Server.services.LoginService;
import com.restWebService.Server.services.ServiceStatusConfig;

@RestController
public class MainRestController {

	@Autowired
	private LoginService service;

	@Autowired
	private AuthConfiguration authConfig;
	
	@Autowired
	private ServiceStatusConfig serviceStatusConfig;

	@CrossOrigin(maxAge = 3600)
	@RequestMapping(value = { "api/2.0/login" }, method = RequestMethod.POST)
	public Object getCredentials(@RequestHeader("Authorization") String authString, HttpServletRequest req) {		
		return authConfig.sessionValidator(authString, req);
	}

	@RequestMapping(value = { "api/2.0/create" }, method = RequestMethod.POST)
	public ResponseEntity<String> newUser(@RequestBody LoginTable newLogin) {
		if (newLogin == null) {
			return ResponseEntity.status(HttpStatus.I_AM_A_TEAPOT).build();
		}

		service.saveNew(newLogin);
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@RequestMapping("/api/2.0/delete")
	public void del(@RequestParam String rn) {
		service.delete(rn);
	}

	@RequestMapping("/api/2.0/update")
	public void update(@RequestParam String rn) {
		LoginTable newEntry = service.update(rn);
		newEntry.setEmail("xyz@gamil.com");
		service.saveNew(newEntry);
	}
	
	@RequestMapping(value = { "api/2.0/loginservice/status" }, method = RequestMethod.GET)
	public Object getStatus() {				
		return serviceStatusConfig.getServiceStatus();
	
	}

}
