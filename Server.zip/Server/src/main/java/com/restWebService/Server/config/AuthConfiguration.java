
package com.restWebService.Server.config;

import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.restWebService.Server.models.Authentication;
import com.restWebService.Server.models.LoginTable;
import com.restWebService.Server.models.ServiceInternalError;
import com.restWebService.Server.models.UserSession;
import com.restWebService.Server.services.ConnectSessionService;
import com.restWebService.Server.services.LoginService;

@Configuration
@Component
public class AuthConfiguration {

	private String roll_no = "";

	@Autowired
	private UserSession userSession;

	@Autowired
	private LoginService service;

	@Autowired
	private Authentication authentication;

	@Autowired
	private ConnectSessionService connectService;

	@Autowired
	private ServiceInternalError authInternalError;

	public Object sessionValidator(String authString) {

		String sessionOrigin = configureGlobalSecurity(authString);
		if (!sessionOrigin.equals("Invalid Credentials")) {

			userSession = connectService.connectToSessionService(roll_no);
			authentication = new Authentication("Authenticated", "OK", "Successful", HttpStatus.OK,
					userSession.getUserSession1(), userSession.getUserSession2(), userSession.getUserSession3(),
					userSession.getUserSession4(), userSession.getUserRoll());
			if (userSession.getStatusCode() != 200) {
				authInternalError = new ServiceInternalError(
						"{Session Request Status: Failed, \n Error Code: Sess400}");
				return authInternalError;
			}
		} else {
			userSession = new UserSession("Sorry! You do not have permission","Sorry! You do not have permission","Sorry! You do not have permission","Sorry! You do not have permission","Sorry! You do not have permission",401);
			authentication = new Authentication("Invalid Credentials", "Failed", "Try again", HttpStatus.NOT_ACCEPTABLE,userSession.getUserSession1(), userSession.getUserSession2(), userSession.getUserSession3(),
					userSession.getUserSession4(), userSession.getUserRoll());
		}
		if (authentication != null) {
			return authentication;
		} else {
			authInternalError = new ServiceInternalError(
					"{Authentication Request Status: Failed, \n Error Code: Auth400}");
			return authInternalError;
		}
	}

	private String configureGlobalSecurity(String encodedString) {

		String decodedString = decoding(encodedString);
		String user = splitUser(decodedString);
		String password = splitPass(decodedString);
		String validateStatus = "";
		if (validate(user, password)) {
			validateStatus = "User Authenticated";
		} else {
			validateStatus = "Invalid Credentials";
		}
		return validateStatus;
	}

	private String decoding(String encodedChunk) {

		String[] wasteUnit = encodedChunk.split(" ");
		String refinedChunk = wasteUnit[1];
		String dataInProgress = decoder(refinedChunk);
		return dataInProgress;
	}

	private String splitUser(String decodedData) {

		String[] splittedString = decodedData.split(":");
		String user = splittedString[0];
		return user;
	}

	private String splitPass(String decodedData) {

		String[] splittedString = decodedData.split(":");
		String Pass = splittedString[1];
		return Pass;
	}

	private boolean validate(String userName, String passWord) {
		boolean flag = false;
		for (LoginTable lt : service.retrieve()) {
			if (lt.getEmail().equals(userName) && lt.getPass().equals(passWord)) {
				flag = true;
				roll_no = lt.getRn();
			}
		}
		return flag;
	}

	private String decoder(String encodedString) {

		byte[] b64 = Base64.getDecoder().decode(encodedString.getBytes());
		String decodedValue = new String(b64);
		return decodedValue;
	}

}