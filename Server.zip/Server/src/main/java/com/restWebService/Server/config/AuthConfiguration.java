
package com.restWebService.Server.config;

import com.restWebService.Server.models.Authentication;
import com.restWebService.Server.models.LoginTable;
import com.restWebService.Server.models.UserSession;
import com.restWebService.Server.services.SessionGenerator;
import com.restWebService.Server.services.ConnectSessionService;
import com.restWebService.Server.services.LoginService;
import java.util.Base64;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Configuration
@Component
public class AuthConfiguration {

	private  String roll_no="";

	@Autowired
	private UserSession userSession;
	
	@Autowired
	private LoginService service;

	@Autowired
	private Authentication authentication;

	@Autowired
	private SessionGenerator sessionHandle;

	@Autowired
	private ConnectSessionService connectService;

	public Object sessionValidator(String authString, HttpServletRequest req) {

		UserSession sessionOrigin = configureGlobalSecurity(authString, req);
		if (!sessionOrigin.getUserId().equals("Invalid Credentials") || !sessionOrigin.getUserSession().equals("Invalid Credentials")) {
			authentication = new Authentication("Authenticated", "OK", "Successful", HttpStatus.OK, sessionOrigin.getUserSession(),sessionOrigin.getUserId());
			
			int responseStatus = connectService.connectToSessionService(sessionOrigin);
			if (responseStatus != 200) {
				return "{Session Request:  Failed, \n Error Code: Sess400}";
			}
		}
		
		else {
			authentication = new Authentication("Invalid Credentials", "Failed", "Try again", HttpStatus.NOT_ACCEPTABLE,
					sessionOrigin.getUserSession(),sessionOrigin.getUserId());
		}
		if (authentication != null) {
			return authentication;
		} else {
			return "{Status: Request Failed,\n Error Code: Auth400}";
		}
	}

	public UserSession configureGlobalSecurity(String encodedString, HttpServletRequest request) {

		String sessionId="";
		String decodedString = decoding(encodedString);
		String user = splitUser(decodedString);
		String password = splitPass(decodedString);
		if (validate(user, password)) {
			sessionId = sessionHandle.getSession(request);
			userSession = new UserSession(sessionId,roll_no);
		} else {
			userSession = new UserSession("Invalid Credentials");
		}
		return userSession;
	}

	private String decoding(String encodedChunk) {

		String[] wasteUnit = encodedChunk.split(" ");
		String refinedChunk = wasteUnit[1];
		String dataInProgress = decoder(refinedChunk);
		return dataInProgress;
	}

	private String splitUser(String decodedData) {

		String[] splittedString = decodedData.split(":");
		String user = splittedString[0];
		return user;
	}

	private String splitPass(String decodedData) {

		String[] splittedString = decodedData.split(":");
		String Pass = splittedString[1];
		return Pass;
	}

	private boolean validate(String userName, String passWord) {
		boolean flag = false;
		for (LoginTable lt : service.retrieve()) {
			if (lt.getEmail().equals(userName) && lt.getPass().equals(passWord)) {
				flag = true;
				roll_no = lt.getRn();
			}
		}
		return flag;
	}

	private String decoder(String encodedString) {

		byte[] b64 = Base64.getDecoder().decode(encodedString.getBytes());
		String decodedValue = new String(b64);
		return decodedValue;
	}

}