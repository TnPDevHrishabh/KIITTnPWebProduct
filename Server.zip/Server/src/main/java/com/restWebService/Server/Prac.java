package com.restWebService.Server;

public class Prac {

	public static void main(String args[]) {

		Outer.Inner ob = new Outer().new Inner();
		ob.show();
	}
}
