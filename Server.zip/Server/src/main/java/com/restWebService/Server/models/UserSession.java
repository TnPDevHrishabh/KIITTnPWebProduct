package com.restWebService.Server.models;

import org.springframework.stereotype.Component;

@Component
public class UserSession {
    
    private String userSession1;
    private String userSession2;
    private String userSession3;
    private String userSession4;
    private String userRoll;
    private int statusCode;

    public UserSession() {
    }

	public UserSession(String userSession1,String userSession2,String userSession3,String userSession4, String userId,int statusCode) {
        this.userSession1 = userSession1;
        this.userSession2 = userSession2;
        this.userSession3 = userSession3;
        this.userSession4 = userSession4;
        this.userRoll = userId;
        this.statusCode = statusCode;
    }

    public String getUserSession1() {
		return userSession1;
	}

	public void setUserSession1(String userSession1) {
		this.userSession1 = userSession1;
	}

	public String getUserSession2() {
		return userSession2;
	}

	public void setUserSession2(String userSession2) {
		this.userSession2 = userSession2;
	}

	public String getUserSession3() {
		return userSession3;
	}

	public void setUserSession3(String userSession3) {
		this.userSession3 = userSession3;
	}

	public String getUserSession4() {
		return userSession4;
	}

	public void setUserSession4(String userSession4) {
		this.userSession4 = userSession4;
	}

	public String getUserRoll() {
		return userRoll;
	}

	public void setUserRoll(String userRoll) {
		this.userRoll = userRoll;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

    
}
