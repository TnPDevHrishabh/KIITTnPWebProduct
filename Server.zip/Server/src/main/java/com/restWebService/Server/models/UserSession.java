package com.restWebService.Server.models;

import org.springframework.stereotype.Component;

@Component
public class UserSession {
    
    private String userSession;
    private String userRoll;

    public UserSession() {
    }
    
    public UserSession(String message) {
		this.userSession = message;
		this.userRoll = message;
	}

	public UserSession(String userSession, String userId) {
        this.userSession = userSession;
        this.userRoll = userId;
    }

    public String getUserSession() {
        return userSession;
    }

    public void setUserSession(String userSession) {
        this.userSession = userSession;
    }

    public String getUserId() {
        return userRoll;
    }

    public void setUserId(String userId) {
        this.userRoll = userId;
    }
    
}
