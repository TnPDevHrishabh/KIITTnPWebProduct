var Geo = {};

$(document).ready(function(){


	var x=Cookies.get('sessionCookie');
	console.log(x);
    if(x!=null){
			console.log("Session Found");
			window.location = "./student/notice.html";
		}



	/*$.getJSON('https://freegeoip.net/json/?callback=?', function(data) {

					Geo.primary = data;
					if(typeof data != 'undefined')
					Geo.primary = data;
					else Geo.primary=null;
			console.clear();
});*/

$("#login").click(function(){

	$("#loginButton").hide();
	$("#empty-error").hide();

	$("#loading").show();

	$("#ceredential-error").hide();
	var email = $("#usr").val();
	var password = $("#pwd").val();
	var userArr = email.split("@");
	var userID = userArr[0];
	//clearOldSessions(userID);
	beginLogin(email,password);
});
});
/*function clearOldSessions(userID){
	$.ajax({
    url: "https://"+api_url+"/api/1.5/connect/logout",
    method: "GET",
    beforeSend: function(xhr){
      xhr.setRequestHeader("userId",userID);
    }
  });
}*/
function beginLogin(email,password){

if( email =='' || password ==''){
	$("#empty-error").show();
	$("#loginButton").show();
	$("#loading").hide();
}
else {

	var payload = email+':'+password;

	$.ajax({
    url: 'https://localhost:4000/api/1.1/connect/login',
    method: 'POST',
    beforeSend: function ( xhr ) {
    	xhr.setRequestHeader('Authorization','Basic ' + btoa(payload));
    	//xhr.setRequestHeader('geo_loc_sec',  JSON.stringify(Geo.primary));
    	console.clear();
    },

    success: function( data, txtStatus, xhr ){
		var check = data.status;
		if(check != "Invalid Credentials"){
			var curTime = new Date;
			var expTime = curTime.getTime() + 30*60*1000;
			curTime.setTime(expTime);

			var pattern = new RegExp('/^15/');
			if(pattern.test(data.rollNo)){
				document.cookie = "registrationCookie="+ data.rollNo+";expires="+curTime.toUTCString;

								window.location = "./studentRegistration.html";
			}
			else{
							document.cookie = "sessionCookie="+ data.sessionId1+" "+data.sessionId2+" "+data.sessionId3+" "+data.sessionId4+ " "+data.rollNo+";expires="+curTime.toUTCString/*+"; path=/"+
												"; geoLocPrimary="+JSON.stringify(Geo.primary)+
												"; geoLocSec="+JSON.stringify(Geo.secondary);*/

																window.location = "./student/notice.html";
			}
			console.clear();
		}
		else{
			$("#loginButton").show();
			$("#ceredential-error").show();
			$("#loading").hide();
			console.clear();
		}
    }

});
}
	console.clear();
}
