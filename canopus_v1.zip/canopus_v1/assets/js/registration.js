$(document).ready(function(){
	var x = Cookies.get('registrationCookie');
	console.log(x);
	if(x != null){
		var details = x.split("=")[1];
		var refinedDetail = details.split(";")[0];
		var userPass = refinedDetail[0].split(" ");
		var userName = userPass[0];
		var rollNo = userName.split("@")[0];
		var newPass = userPass[1];
		Cookies.remove('registrationCookie');
	}
	else{
		window.location = "./student2019login.html";
	}

	$("#register").click(function(){
		var branch = $("#branch").val();
		var dob = $("#dob").val();
		var fname = $("#fname").val();
		var mname = $("#mname").val();
		var mob = $("#mob").val();
		var jsonPayload = '{"rollNo": rollNo,"passWord": newPass,"mobNo": mob,"dob": dob,"fatherName": fname,"motherName": mname,"branch": branch}';
		var payload = userName+":"+newPass;
		var jsonData = JSON.parse(jsonPayload);
		  $.ajax({
				url: "http://localhost:2000/api/phase2/1.3/dummyservice",
				data: JSON.stringify(jsonData),
				contentType: "application/json",
				dataType: "JSON",
				type: "GET",
				beforeSend: function(xhr){
					xhr.setRequestHeader("Authorization","Basic "+btoa(payload));
				},
				complete: function(xhr,status){
					console.log(status);
				}
			});
	});
});
