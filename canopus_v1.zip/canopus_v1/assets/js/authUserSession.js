
$(document).ready(function(){
	var UTCstring = luxon.DateTime.local().setZone('Asia/Kolkata').toISODate();
	var today = UTCstring;
	var yesterday = luxon.DateTime.local().setZone('Asia/Kolkata').minus({day:1}).toISODate();
		console.clear();
		$("#loaderDiv").show();
		$("#main-notice").hide();
		var x=Cookies.get('sessionCookie');
    if(x==null){
			window.location = "../login.html";
		}
	else{
	var y = x.split(" ");
	var p = Cookies.get('geo_loc_primary');
	var s = Cookies.get('geo_loc_sec');
	$("#userId").append(y[y.length - 1] + "@kiit.ac.in");

    $.ajax({
        url: "https://"+api_url+"/api/1.2/connect/notice",
	    dataType: 'JSON',
        type: 'GET',
		beforeSend: function( xhr ){
			xhr.setRequestHeader("RollNo",y[y.length - 1]);
			xhr.setRequestHeader("sessionId1",y[0]);
			xhr.setRequestHeader("sessionId2",y[1]);
			xhr.setRequestHeader("sessionId3",y[2]);
			xhr.setRequestHeader("sessionId4",y[3]);
		},

        success: function (data) {
			if(data.message == "Access Denied"){
			Cookies.remove('sessionCookie');
			window.location = "../login.html";
		}
		else if(data.message == "Session Expired"){
			Cookies.remove('sessionCookie');
			Cookies.remove('sessionCookie');			
			window.location = "../login.html";
		}
		else if(data.message == "Count Exceeded"){
			Cookies.remove('sessionCookie');						
			window.location = "../login.html";
				}
		else{
			var _MS_PER_DAY = 1000 * 60 * 60 * 24;
			function getDiff(sdate,edate){
				var ed = new Date(edate),
    				st = new Date(sdate);
				var td = new Date(today);				
				var tdd = Date.UTC(td.getFullYear(), td.getMonth(), td.getDate());
  				var edd = Date.UTC(ed.getFullYear(), ed.getMonth(), ed.getDate());
  				var diffDays =  Math.floor((edd - tdd) / _MS_PER_DAY);
  				if(edd>=tdd)
  					var msg="future"
  				else
  					var msg="past";
  				var obj = { "st":sdate,
  							"en":edate,
  							"td":today,
  							"diff": diffDays,
  							"msg":msg};
				
				return obj;
			}

			function reformatDate(dateStr, offset)
			{
			  var dArr = dateStr.split("-");  // ex input "2010-01-18"
			  var mArr= ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
			  var date = dArr[2]-offset+ "-" +mArr[parseInt(dArr[1]-1)]+ "-" +dArr[0]; 
			  
			  return date;
			}

			$(data).each(function (index, value) {

        		var dtObj = getDiff(value.st_dt,value.en_dt);
        		if(dtObj.msg==="future"){
        			console.log(dtObj.en);
	     			var noticeLink = value.link.split('..');
	     			var link="https://notice.kiittnp.in"+noticeLink[1];
	     			var howOld = findStatus(value.st_dt, value.en_dt);
	     			var postedOn = "<span class='badge badge-pill badge-primary' id='badge-post'>Posted On: "+reformatDate(value.st_dt,0)+"</span>";
	     			var status = "<div class='container inline-block' id='status'>"+postedOn+howOld+"</div>";
	     			var expires =reformatDate(value.en_dt,1);


			 		$('.notice-container').append("<div class='notice'><div class='user row'>"+
			 			status+"<span class='notice-header' ><p id='heading' >"+
			 			value.heading+"</p></span><div class='notice-header-date col-md-12 col-sm-12'><h4 class='badge badge-dark' id='expires'>Last Date To Apply: <strong>"+
			 			expires+"</strong></h4></div><div class='col-md-12 col-sm-12' style='display:block;'><a target='_blank' href="+
			 			link+" ><button class='button_notice button1_notice'>Download Notice</button></a></div></div></div>");
			
				}
			});
			$('.navbar').load( function(){});
			$("#loaderDiv").delay(1000).hide();
			$("#main-notice").show();
		}
		}
    });
	}

$("#logout").on("click",function(){
  $.ajax({
    url: "https://"+api_url+"/api/1.5/connect/logout",
    method: "GET",
    beforeSend: function(xhr){
      xhr.setRequestHeader("userId",y[y.length - 1]);
    },
    complete: function(){
			Cookies.remove('sessionCookie');
			window.location = "../login.html";
    }
  });
});
console.clear();
function findStatus(date,end){

	var _MS_PER_DAY = 1000 * 60 * 60 * 24;			
				var ed = new Date(end);
				var td = new Date(today);				
				var tdd = Date.UTC(td.getFullYear(), td.getMonth(), td.getDate());
  				var edd = Date.UTC(ed.getFullYear(), ed.getMonth(), ed.getDate());
  				var diffDays =  Math.floor((edd - tdd) / _MS_PER_DAY);

  	if(diffDays<=0)
  				return "<span class='badge badge-pill badge-dark text-right' id='badge-exp'>expired</span>";
  	else{
		if (date===today)
			return "<span class='badge badge-pill badge-success text-right' id='badge-td'>new</span>";
		else if(date===yesterday)
			return "<span class='badge badge-pill badge-primary text-right' id='badge-yd'>recently added</span>";
		else
			return "<span class='badge badge-pill badge-dark text-right' id='badge-rec'>active</span>"
	}
}
console.clear();
});


