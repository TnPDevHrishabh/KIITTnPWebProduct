$(document).ready(function(){
    $("#show").click(function(){
        $("members").show();
    });
