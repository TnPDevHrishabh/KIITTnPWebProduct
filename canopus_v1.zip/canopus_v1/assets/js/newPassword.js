 $(document).ready(function(){
   var x = Cookies.get('registrationCookie');
   console.log(x);
   if(x != null){
     var cookieValue = x.split('=');
     var rollValue = cookieValue[1].split(';');
     var rollNo = rollValue[0];
     var userName = rollNo+"@kiit.ac.in";
     document.getElementById('email').value = userName;
   }
   else{
     window.location = "./student2019login.html";
   }

    $("#login").click(function(){
      var newPass = $("#passkey").val();
      var cpass = $("#cpasskey").val();
      if(newPass === cpass){
        var newPassword = $("#cpasskey").val();
        var newCookieValue = userName+" "+newPassword;
        var curTime = new Date;
  			var expTime = curTime.getTime() + 30*60*1000;
  			curTime.setTime(expTime);
        document.cookie = "registrationCookie="+newCookieValue+";expires="+curTime.toUTCString;
        window.location = "./registrationDetails.html";
      }
      else{
        alert("There is a mismatch in your password conformation !");
        $("#passkey").val('');
        $("#cpasskey").val('');
      }
    });
 });
