package com.kiit_tnp.api.SessionService.SessionServer.SessionManager;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SessionManagerApplicationTests {

	@Test
	public void contextLoads() {
	}

}
