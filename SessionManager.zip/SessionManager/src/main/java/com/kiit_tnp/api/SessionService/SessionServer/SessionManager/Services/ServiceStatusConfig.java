package com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Services;

import org.springframework.stereotype.Component;

import com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Model.ServiceStatus;

@Component
public class ServiceStatusConfig {
	
	public ServiceStatus getServiceStatus() {
		
		return new ServiceStatus("running");
	}

}
