package com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Model;

import org.springframework.stereotype.Component;

@Component
public class ServiceStatus {

	private String status;
	
	public ServiceStatus() {
		super();
	}

	public ServiceStatus(String status) {
		super();
		this.status = status;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
}
