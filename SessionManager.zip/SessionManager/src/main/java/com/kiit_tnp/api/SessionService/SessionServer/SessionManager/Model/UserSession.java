package com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Model;



public class UserSession {
    
    private String userSession;
    private String userRoll;

    public UserSession(String sessionChunk, String id) {
        this.userSession = sessionChunk;
        this.userRoll = id;
    }

    public UserSession() {
    }

    public String getUserSession() {
        return userSession;
    }

    public void setUserSession(String userSession) {
        this.userSession = userSession;
    }

    public String getUserRoll() {
        return userRoll;
    }

    public void setUserRoll(String userRoll) {
        this.userRoll = userRoll;
    }

    
}
