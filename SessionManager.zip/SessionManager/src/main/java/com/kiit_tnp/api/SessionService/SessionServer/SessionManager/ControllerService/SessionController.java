
package com.kiit_tnp.api.SessionService.SessionServer.SessionManager.ControllerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Model.ServiceInternalError;
import com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Model.UserSession;
import com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Services.ServiceStatusConfig;
import com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Services.SessionRepoService;
import com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Services.SessionTableMaster;

@RestController
public class SessionController {
	
	private static final String logoutKey = "77a9ccfd-2f33-4277-b774-6a150aee61be";
    
    @Autowired
    private SessionTableMaster sessionTableMaster;
    
    @Autowired
	private SessionRepoService sessionService;
    
    @Autowired
    private ServiceStatusConfig serviceStatusConfig;
    
    @Autowired
    private ServiceInternalError error;
    
    @RequestMapping(value = "/api/2.2/session/new",method = RequestMethod.GET)
    public UserSession InjectSession(@RequestHeader(value = "userId") String userId){
        
    	return sessionTableMaster.updateSessionTable(userId);
    }
    
    @RequestMapping(value = "api/2.2/session/notice",method = RequestMethod.GET)
    public String checkUser(@RequestHeader (value = "userSession1" ) String userSession1,@RequestHeader (value = "userSession2") String userSession2,@RequestHeader(value="id") String userId) {
    	
    	return sessionTableMaster.noticeRequestValidator(userId,userSession1,userSession2);
	}
    
    @RequestMapping(value = "/api/2.2/logout",method = RequestMethod.GET)
    public Object logoutUser(@RequestHeader(value = "RequestFromUI_Roll") String pk,@RequestHeader(value = "MasterKey") String key) {
    	
    	if(key.equals(logoutKey)) {
    		sessionService.deleteById(pk);
    		error = new ServiceInternalError("No Error");
    		return error;
    	}
    	else {
			error = new ServiceInternalError("{Warning : Unauthorized Request}");
			return error;
		}
    }
    
    @RequestMapping(value = { "api/2.2/sessionservice/status" }, method = RequestMethod.GET)
	public Object getStatus() {				
		return serviceStatusConfig.getServiceStatus();
	
	}
    
	

	
	
}
