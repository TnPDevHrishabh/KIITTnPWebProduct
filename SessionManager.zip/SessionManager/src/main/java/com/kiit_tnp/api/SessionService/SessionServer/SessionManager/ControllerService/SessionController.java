
package com.kiit_tnp.api.SessionService.SessionServer.SessionManager.ControllerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Services.ServiceStatusConfig;
import com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Services.SessionRepoService;
import com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Services.SessionTableMaster;

@RestController
public class SessionController {
    
    @Autowired
    private SessionTableMaster sessionTableMaster;
    
    @Autowired
	private SessionRepoService sessionService;
    
    @Autowired
    private ServiceStatusConfig serviceStatusConfig;
    
    @RequestMapping(value = "/api/2.2/session/new")
    public void InjectSession(@RequestHeader (value = "userSession" ) String userSession , @RequestHeader(value = "userId") String userId){
        
    	sessionTableMaster.updateSessionTable(userSession, userId);
    }
    
    @RequestMapping(value = "api/2.2/session/notice")
    public String checkUser(@RequestHeader(value="id") String userId) {
    	
    	return sessionTableMaster.noticeRequestValidator(userId);
	}
    
    @CrossOrigin(maxAge = 3600)
    @RequestMapping(value = "/api/2.2/logout")
    public void logoutUser(@RequestHeader(value = "userId") String pk) {
    	sessionService.deleteById(pk);
    }
    
    @RequestMapping(value = { "api/2.2/sessionservice/status" }, method = RequestMethod.GET)
	public Object getStatus() {				
		return serviceStatusConfig.getServiceStatus();
	
	}
    
	

	
	
}
