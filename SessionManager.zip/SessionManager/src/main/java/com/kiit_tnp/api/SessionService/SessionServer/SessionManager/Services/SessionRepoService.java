
package com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Services;

import com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Model.SessionModel;
import com.kiit_tnp.api.SessionService.SessionServer.SessionManager.SessionReository.SessionRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SessionRepoService {
    
    @Autowired
    private SessionRepo repoObject;
    
    public void insertSession(SessionModel newEntry){
        
        repoObject.save(newEntry);
    }
    
    public SessionModel getSingleRow(String pk){
        
        SessionModel sessionmodel = repoObject.findOne(pk);
        return sessionmodel;
    }
    
    public void deleteByModel(SessionModel t){
        repoObject.delete(t);
    }
    
    public void deleteById(String id) {
    	repoObject.delete(id);
    }
}
