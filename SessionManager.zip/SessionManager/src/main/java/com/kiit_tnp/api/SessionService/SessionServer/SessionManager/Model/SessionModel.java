
package com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Model;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name = "session_handler")
public class SessionModel{
    
    @Id
    @Column(name = "user_id")
    private String userId;
    
    @Column(name = "session_id_1",nullable = false)
    private String sessionId1;
    
    @Column(name = "session_id_2",nullable = false)
    private String sessionId2;
    
    public String getSessionId2() {
		return sessionId2;
	}

	public void setSessionId2(String sessionId2) {
		this.sessionId2 = sessionId2;
	}

	@Column(name = "generated_time")
    private Timestamp startTime;
    
    @Column(name = "count")
    private int count;

    public String getSessionId1() {
        return sessionId1;
    }

    public void setSessionId1(String sessionId) {
        this.sessionId1 = sessionId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Timestamp getStartTime() {
        return startTime;
    }

    public void setStartTime(Timestamp startTime) {
        this.startTime = startTime;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
