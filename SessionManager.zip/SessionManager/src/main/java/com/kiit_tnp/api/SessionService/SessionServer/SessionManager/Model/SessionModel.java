
package com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Model;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import org.springframework.stereotype.Component;

@Component
@Entity(name = "session_handler")
public class SessionModel{
    
    @Id
    @Column(name = "user_id")
    private String userId;
    
    @Column(name = "session_id",nullable = false)
    private String sessionId;
    
    @Column(name = "generated_time")
    private Timestamp startTime;
    
    @Column(name = "count")
    private int count;

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Timestamp getStartTime() {
        return startTime;
    }

    public void setStartTime(Timestamp startTime) {
        this.startTime = startTime;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
