package com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Services;

import java.util.UUID;

import org.springframework.stereotype.Component;

@Component
public class SessionGenerator {
    
    private String session;
    
    public String getSession(){
    
        String message="";
            String sessionId = retrieveSession();
            message = sessionId;
        return message;
    }
    
    private String retrieveSession(){
        
    	session = UUID.randomUUID().toString();
        return session;
    }
    
}
