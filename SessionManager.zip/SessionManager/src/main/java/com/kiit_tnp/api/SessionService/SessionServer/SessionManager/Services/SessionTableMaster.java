package com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Services;

import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Model.SessionModel;
import com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Model.UserSession;

@Component
public class SessionTableMaster {
	
	@Autowired
	private SessionGenerator sessionGenerator;

	private final static long expireTime = 1 * 60 * 1000;

	@Autowired
	private SessionModel newEntry, entry;

	@Autowired
	private SessionRepoService sessionService;
	
	@Autowired
	private UserSession userSession;

	public UserSession updateSessionTable(String rollNo) {
		
		String sessionId1 = sessionGenerator.getSession();
		String sessionId2 = sessionGenerator.getSession();
		String sessionId3 = sessionGenerator.getSession();
		String sessionId4 = sessionGenerator.getSession();

		if (checkExists(rollNo)) {
			
			String response = updateExisting(rollNo, true);
			String[] previousSession = response.split(" ");
			userSession = new UserSession(sessionId1,previousSession[0],sessionId3,previousSession[1],rollNo,200);
			return userSession;
		} else {
			updateNew(sessionId1,sessionId2,sessionId3,sessionId4, rollNo);
			userSession = new UserSession(sessionId1,sessionId2,sessionId3,sessionId4,rollNo,200);
			return userSession;
		}
	}

	public String noticeRequestValidator(String userId, String userSession1, String userSession2) {

		String message = "";

		if (!checkExists(userId)) {
			message = "Access Denied";
		} else {
			
			newEntry = sessionService.getSingleRow(userId);
			if (newEntry.getSessionId1().equals(userSession1) && newEntry.getSessionId2().equals(userSession2)) {

				if (checkExpiry(newEntry)) {
					sessionService.deleteByModel(newEntry);
					message = "Session Expired";
					// delete the cookie as well.
				} else if (checkOverload(newEntry)) {
					message = "Count Exceeded";
					// js code will delete the cookie.
				} else {
					updateExisting(userId, false);
					message = "Access Granted";
				}

			}
			else {
				message = "Access Denied";
			}
		}
		return message;
	}

	private boolean checkExists(String sessionPk) {

		boolean flag = false;
		newEntry = sessionService.getSingleRow(sessionPk);

		if (newEntry != null) {
			flag = true;
		}
		return flag;
	}

	private boolean checkExpiry(SessionModel obj) {

		Timestamp old = obj.getStartTime();
		long oldTime = old.getTime();
		long currentTimeMillis = System.currentTimeMillis();
		long diff = (currentTimeMillis - oldTime);

		if (diff >= expireTime) {
			return true;
		} else {
			return false;
		}
	}

	private boolean checkOverload(SessionModel obj) {

		if (obj.getCount() > 2) {
			return true;
		} else {
			return false;
		}
	}

	private String updateExisting(String roll, boolean flag) {

		Timestamp curTime = new Timestamp(System.currentTimeMillis());
		newEntry = sessionService.getSingleRow(roll);
		String sessionResponse = "";
		
		if (flag) {
			sessionResponse = newEntry.getSessionId1()+" "+newEntry.getSessionId2();
			newEntry.setStartTime(curTime);
			newEntry.setCount(newEntry.getCount() + 1);
		} else {
			newEntry.setStartTime(curTime);
		}

		sessionService.insertSession(newEntry);
		return sessionResponse;
	}

	private void updateNew(String session1, String session2,String session3,String session4, String roll) {

		Timestamp curTime = new Timestamp(System.currentTimeMillis());

		entry.setSessionId1(session2);
		entry.setSessionId2(session4);
		entry.setUserId(roll);
		entry.setCount(1);
		entry.setStartTime(curTime);

		sessionService.insertSession(entry);
	}
}
