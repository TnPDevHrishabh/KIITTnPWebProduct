package com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Services;

import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Model.SessionModel;

@Component
public class SessionTableMaster {

	private final static long expireTime = 1 * 60 * 1000;

	@Autowired
	private SessionModel newEntry, entry;

	@Autowired
	private SessionRepoService sessionService;

	public void updateSessionTable(String userSession, String rollNo) {

		if (checkExists(rollNo)) {
			updateExisting(rollNo, true);
		} else {
			updateNew(userSession, rollNo);
		}
	}

	public String noticeRequestValidator(String userId) {

		newEntry = sessionService.getSingleRow(userId);
		String message = "";

		if (!checkExists(userId)) {
			message = "Access Denied";
		} else {

			if (checkExpiry(newEntry)) {
				sessionService.deleteByModel(newEntry);
				message = "Session Expired";
				// delete the cookie as well.
			} else if (checkOverload(newEntry)) {
				message = "Count Exceeded";
				// js code will delete the cookie.
			} else {
				updateExisting(userId, false);
				message = "Access Granted";
			}

		}
		return message;
	}

	private boolean checkExists(String sessionPk) {

		boolean flag = false;
		newEntry = sessionService.getSingleRow(sessionPk);

		if (newEntry != null) {
			flag = true;
		}
		return flag;
	}

	private boolean checkExpiry(SessionModel obj) {

		Timestamp old = obj.getStartTime();
		long oldTime = old.getTime();
		long currentTimeMillis = System.currentTimeMillis();
		long diff = (currentTimeMillis - oldTime);

		if (diff >= expireTime) {
			return true;
		} else {
			return false;
		}
	}

	private boolean checkOverload(SessionModel obj) {

		if (obj.getCount() > 2) {
			return true;
		} else {
			return false;
		}
	}

	private void updateExisting(String roll, boolean flag) {

		Timestamp curTime = new Timestamp(System.currentTimeMillis());
		newEntry = sessionService.getSingleRow(roll);

		if (flag == true) {
			newEntry.setStartTime(curTime);
			newEntry.setCount(newEntry.getCount() + 1);
		} else {
			newEntry.setStartTime(curTime);
		}

		sessionService.insertSession(newEntry);
	}

	private void updateNew(String session, String roll) {

		Timestamp curTime = new Timestamp(System.currentTimeMillis());

		entry.setSessionId(session);
		entry.setUserId(roll);
		entry.setCount(1);
		entry.setStartTime(curTime);

		sessionService.insertSession(entry);
	}
}
