
package com.kiit_tnp.api.SessionService.SessionServer.SessionManager.SessionReository;

import com.kiit_tnp.api.SessionService.SessionServer.SessionManager.Model.SessionModel;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

@Component
public interface SessionRepo extends CrudRepository<SessionModel, String>{
    
}
