$(window).on('load', function() {
	//var loginPageUrl = "./empty.html";
	$(".se-pre-con").delay(2000).fadeOut("slow");
		var x=Cookies.get('sessionCookie');
    if(x==null){
		window.location = "../login.html";
	}
	else{
	console.log(x);
    $.ajax({
        url: "http://localhost:9000/api/2.1/notices",
	    dataType: 'JSON',
        type: 'GET',
		beforeSend: function( xhr ){
			xhr.setRequestHeader("RollNo",x);
		},

        success: function (data) {
		//this is a double check, as there would'nt be any cookie for the user who is getting this message. Thereby, checking cookie injection.
		if(data.message == "Access Denied"){
			console.log("Please Authenticate Yourself !!");
			window.location = "../login.html";
		}
		else if(data.message == "Session Expired"){
			console.log(data.message);
			Cookies.remove('sessionCookie');
			//this will futher hit the logout service. i.e. delete the row from the session table.
			window.location.reload();
		}
		else if(data.message == "Count Exceeded"){
			console.log(data.message);
			Cookies.remove('sessionCookie');
			//this will not delete the session row from the table because the user may be active on the other browser.
		}
		else{
		$(data).each(function (index, value) {
     //var eachpanel = "<div class='panel panel-default' style='margin-top:3%; margin-left:10%; width:80%;box-shadow: 0px 10px 10px rgba(0, 0, 0, 0.3);'><div class='panel-heading panel-heading-custom'>"+value.st_dt+"</div>"+"<div class='panel-body'>"+value.bd+"<a href='"+value.link+"' style='float:right;'>Click Here To Download</a></div></div>";
     //$('#panalid').append(eachpanel);
		 $('.notice-container').append("<div class='notice'><div class='user row'><div class='notice-header col-md-12 col-sm-12' ><h3>"+value.bd+"</h3></div><div class='notice-header-date col-md-12 col-sm-12'><h3>Date:"+value.st_dt+"</h3></div><span class='notice-header col-md-12 col-sm-12'><p>"+value.des+"</p></span><div class='col-md-12 col-sm-12' style='display:block;'><a target='_blank' href="+value.link+" ><button class='button_notice button1_notice'>Download Notices</button></a></div></div></div>");
		});
		}
		}
    });
	}

$("#logout").on("click",function(){
  $.ajax({
    url: "http://localhost:7777/api/2.2/logout",
    method: "GET",
    beforeSend: function(xhr){
      xhr.setRequestHeader("userId",x);
    },
    complete: function(){
      window.location.reload();
    }
  });
});
});
