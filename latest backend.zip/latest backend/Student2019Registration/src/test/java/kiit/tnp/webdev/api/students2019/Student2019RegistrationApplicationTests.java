package kiit.tnp.webdev.api.students2019;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class Student2019RegistrationApplicationTests {

	@Test
	public void contextLoads() {
	}

}
