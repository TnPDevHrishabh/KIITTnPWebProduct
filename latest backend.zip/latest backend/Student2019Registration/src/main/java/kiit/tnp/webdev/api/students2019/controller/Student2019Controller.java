package kiit.tnp.webdev.api.students2019.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import kiit.tnp.webdev.api.students2019.model.NewStudents;
import kiit.tnp.webdev.api.students2019.service.AuthService;
import kiit.tnp.webdev.api.students2019.service.StudentRepoService;

@RestController
public class Student2019Controller {

	@Autowired
	private StudentRepoService controllerService;
	
	@Autowired
	private AuthService authService;
	
	//Admin Service
	@RequestMapping(value = "/api/phase2/1.0/insertdata", method = RequestMethod.POST)
	public void pushStudentData(@RequestBody List<NewStudents> newStudent) {
		
		controllerService.insertData(newStudent);
	}
	
	@RequestMapping(value = "/api/phase2/1.1/getdata", method = RequestMethod.GET)
	public List<NewStudents> getData(){
		
		return controllerService.returnData();
	}
	
	@RequestMapping(value = "/api/phase2/1.2/authenticatestudent",method = RequestMethod.GET)
	public String newStudentAuthentication(@RequestHeader(value = "userId") String uId,@RequestHeader(value = "password") String pass) {
		
		return authService.authenticatingUser(uId,pass);
	}
}
