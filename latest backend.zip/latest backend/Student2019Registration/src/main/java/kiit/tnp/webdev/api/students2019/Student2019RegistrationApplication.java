package kiit.tnp.webdev.api.students2019;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Student2019RegistrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(Student2019RegistrationApplication.class, args);
	}
}
