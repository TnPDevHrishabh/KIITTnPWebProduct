package kiit.tnp.webdev.api.students2019.service;

import java.util.ArrayList;
import java.util.List;
import javax.transaction.Transactional;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import kiit.tnp.webdev.api.students2019.daorepo.Student2019Repo;
import kiit.tnp.webdev.api.students2019.model.NewStudents;

@Component
public class StudentRepoService {

	@Autowired
	private Student2019Repo studentRepo;

	@Transactional
	public void insertData(List<NewStudents> newStudent) {
		
		for(NewStudents ns : newStudent) {
			ns.setPassWord(RandomStringUtils.randomAlphanumeric(8).toUpperCase());
		}
		studentRepo.saveAll(newStudent);
	}
	
	@Transactional
	public List<NewStudents> returnData(){
		
		List<NewStudents> studentList = new ArrayList<>();
		for(NewStudents newStudent : studentRepo.findAll()) {
			studentList.add(newStudent);
		}
		
		return studentList;
	}
}
