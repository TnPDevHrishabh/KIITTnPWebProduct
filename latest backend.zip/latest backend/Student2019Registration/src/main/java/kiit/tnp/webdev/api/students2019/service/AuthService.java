package kiit.tnp.webdev.api.students2019.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import kiit.tnp.webdev.api.students2019.model.NewStudents;

@Component
public class AuthService {
	
	@Autowired
	private StudentRepoService studentRepoService;
	
	public String authenticatingUser(String uId,String pass) {
		
		String message = "";
		for(NewStudents ns : studentRepoService.returnData()) {
			if(ns.getRollNo().equals(uId) && ns.getPassWord().equals(pass)) {

				message = "New Student Authenticated:"+uId;
				break;
			}
			else {
				message = "Invalid Credentials";
			}
		}
		return message;
	}
}
