package kiit.tnp.webdev.api.students2019.daorepo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

import kiit.tnp.webdev.api.students2019.model.NewStudents;

@Component
public interface Student2019Repo extends CrudRepository<NewStudents, String>{

}
