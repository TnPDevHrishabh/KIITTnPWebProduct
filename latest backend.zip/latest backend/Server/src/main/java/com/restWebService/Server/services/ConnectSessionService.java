package com.restWebService.Server.services;

import com.restWebService.Server.models.UserSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class ConnectSessionService {

	@Autowired
	private UserSession userSession;

	private static final String url = "http://localhost:7777/api/2.2/session/new";

	public UserSession connectToSessionService(String rollNo) {
		ResponseEntity<UserSession> response = connect(rollNo);
		userSession = new UserSession(response.getBody().getUserSession1(), response.getBody().getUserSession2(),
				response.getBody().getUserSession3(), response.getBody().getUserSession4(),
				response.getBody().getUserRoll(), response.getStatusCodeValue());
		return userSession;
	}

	private ResponseEntity<UserSession> connect(String uId) {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.add("userId", uId);
		HttpEntity<String> request = new HttpEntity<String>(headers);
		ResponseEntity<UserSession> response = restTemplate.exchange(url, HttpMethod.GET, request, UserSession.class);
		return response;
	}
}
