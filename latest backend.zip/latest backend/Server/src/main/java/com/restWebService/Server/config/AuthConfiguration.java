
package com.restWebService.Server.config;

import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.restWebService.Server.models.Authentication;
import com.restWebService.Server.models.LoginTable;
import com.restWebService.Server.models.ServiceInternalStatus;
import com.restWebService.Server.models.UserSession;
import com.restWebService.Server.services.ConnectSessionService;
import com.restWebService.Server.services.ConnectTo2019Students;
import com.restWebService.Server.services.LoginService;

@Configuration
@Component
public class AuthConfiguration {

	@Autowired
	private UserSession userSession;

	@Autowired
	private LoginService service;

	@Autowired
	private Authentication authentication;

	@Autowired
	private ConnectSessionService connectService;

	@Autowired
	private ServiceInternalStatus authInternalStatus;
	
	@Autowired
	private ConnectTo2019Students connect2019students;

	public Object sessionValidator(String authString) {
		
		String sessionOrigin = configureGlobalSecurity(authString);
		if (!sessionOrigin.equals("Invalid Credentials")) {
			userSession = connectService.connectToSessionService(sessionOrigin.split(":")[1]);
			authentication = new Authentication("Authenticated", "OK", "Successful", HttpStatus.OK,
					userSession.getUserSession1(), userSession.getUserSession2(), userSession.getUserSession3(),
					userSession.getUserSession4(), userSession.getUserRoll());
			if (userSession.getStatusCode() != 200) {
				authInternalStatus = new ServiceInternalStatus(
						"{Session Request Status: Failed, \n Error Code: Sess400}");
				return authInternalStatus;
			}
			
		} else {
			userSession = new UserSession("Sorry! You do not have permission","Sorry! You do not have permission","Sorry! You do not have permission","Sorry! You do not have permission","Sorry! You do not have permission",401);
			authentication = new Authentication("Invalid Credentials", "Failed", "Try again", HttpStatus.NOT_ACCEPTABLE,userSession.getUserSession1(), userSession.getUserSession2(), userSession.getUserSession3(),
					userSession.getUserSession4(), userSession.getUserRoll());
		}
		if (authentication != null) {
			return authentication;
		} else {
			authInternalStatus = new ServiceInternalStatus(
					"{Authentication Request Status: Failed, \n Error Code: Auth400}");
			return authInternalStatus;
		}
	}

	private String configureGlobalSecurity(String encodedString) {

		String regex = "^15.*";
		String decodedString = decoding(encodedString);
		String user = splitUser(decodedString);
		String password = splitPass(decodedString);
		if(user.matches(regex)) {
			return callingConnectionService(user, password);
		}
		else {
			String validateStatus = "";
			if (validate(user, password)) {
				validateStatus = "User Authenticated:"+user.split("@")[0];
			} else {
				validateStatus = "Invalid Credentials";
			}
			return validateStatus;
		}
		
	}
	
	private String callingConnectionService(String uId,String pass) {
		
		ResponseEntity<String> response = connect2019students.connectToNewStudents(uId.split("@")[0],pass);
		
			return response.getBody();
	}

	private String decoding(String encodedChunk) {

		String[] wasteUnit = encodedChunk.split(" ");
		String refinedChunk = wasteUnit[1];
		String dataInProgress = decoder(refinedChunk);
		return dataInProgress;
	}

	private String splitUser(String decodedData) {

		String[] splittedString = decodedData.split(":");
		String user = splittedString[0];
		return user;
	}

	private String splitPass(String decodedData) {

		String[] splittedString = decodedData.split(":");
		String Pass = splittedString[1];
		return Pass;
	}

	private boolean validate(String userName, String passWord) {
		boolean flag = false;
		for (LoginTable lt : service.retrieve()) {
			if (lt.getEmail().equals(userName) && lt.getPass().equals(passWord)) {
				flag = true;
			}
		}
		return flag;
	}

	private String decoder(String encodedString) {

		byte[] b64 = Base64.getDecoder().decode(encodedString.getBytes());
		String decodedValue = new String(b64);
		return decodedValue;
	}

}