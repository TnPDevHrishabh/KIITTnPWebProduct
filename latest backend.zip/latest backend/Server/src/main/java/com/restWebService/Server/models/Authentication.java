
package com.restWebService.Server.models;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class Authentication {
    
    private String status;
    private String response;
    private String message;
    private HttpStatus httpStatus;
    private String sessionId1;
    private String sessionId2;
    private String sessionId3;
    private String sessionId4;
    private String rollNo;

    public Authentication() {
        
    }
    
    public Authentication(String status, String response, String message, HttpStatus httpStatus, String sessionId1,String sessionId2,String sessionId3,String sessionId4,String rollNo) {
        this.status = status;
        this.response = response;
        this.message = message;
        this.httpStatus = httpStatus;
        this.sessionId1 = sessionId1;
        this.sessionId2 = sessionId2;
        this.sessionId3 = sessionId3;
        this.sessionId4 = sessionId4;
        this.rollNo = rollNo;
    }
    
     public String getSessionId1() {
		return sessionId1;
	}

	public void setSessionId1(String sessionId1) {
		this.sessionId1 = sessionId1;
	}

	public String getSessionId2() {
		return sessionId2;
	}

	public void setSessionId2(String sessionId2) {
		this.sessionId2 = sessionId2;
	}

	public String getSessionId3() {
		return sessionId3;
	}

	public void setSessionId3(String sessionId3) {
		this.sessionId3 = sessionId3;
	}

	public String getSessionId4() {
		return sessionId4;
	}

	public void setSessionId4(String sessionId4) {
		this.sessionId4 = sessionId4;
	}
    
     public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    public void setHttpStatus(HttpStatus httpStatus) {
        this.httpStatus = httpStatus;
    }
    
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

	public String getRollNo() {
		return rollNo;
	}

	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}
    
}
