package com.restWebService.Server.services;

import org.springframework.stereotype.Component;

import com.restWebService.Server.models.ServiceStatus;

@Component
public class ServiceStatusConfig {
	
	public ServiceStatus getServiceStatus() {
		
		return new ServiceStatus("running");
	}

}
