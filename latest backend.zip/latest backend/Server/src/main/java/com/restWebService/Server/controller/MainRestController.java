package com.restWebService.Server.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.restWebService.Server.config.AuthConfiguration;
import com.restWebService.Server.models.ServiceInternalStatus;
import com.restWebService.Server.models.LoginTable;
import com.restWebService.Server.services.LoginService;
import com.restWebService.Server.services.ServiceStatusConfig;

@RestController
public class MainRestController {

	private static final String loginKey = "485c0e4e-f425-4fd7-bb58-1f43ca54b673";

	@Autowired
	private LoginService service;

	@Autowired
	private AuthConfiguration authConfig;

	@Autowired
	private ServiceStatusConfig serviceStatusConfig;
	
	@Autowired
	private ServiceInternalStatus authInternalError;

	@RequestMapping(value = { "api/2.0/login" }, method = RequestMethod.GET)
	public Object getCredentials(@RequestHeader("RequestFromUI") String authString,
			@RequestHeader("MasterKey") String passKey) {

		if (passKey.equals(loginKey)) {
			return authConfig.sessionValidator(authString);
		} else {
			authInternalError = new ServiceInternalStatus("{Warning : Unauthorized Request}");
			return authInternalError;
		}
	}

	@Deprecated
	@RequestMapping(value = { "api/2.0/create" }, method = RequestMethod.POST)
	public ResponseEntity<String> newUser(@RequestBody LoginTable newLogin) {
		if (newLogin == null) {
			return ResponseEntity.status(HttpStatus.I_AM_A_TEAPOT).build();
		}

		service.saveNew(newLogin);
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@Deprecated
	@RequestMapping(value = {"/api/2.0/delete"},method = RequestMethod.GET)
	public void del(@RequestParam String rn) {
		service.delete(rn);
	}

	@Deprecated
	@RequestMapping("/api/2.0/update")
	public void update(@RequestParam String rn) {
		LoginTable newEntry = service.update(rn);
		newEntry.setEmail("xyz@gamil.com");
		service.saveNew(newEntry);
	}

	@RequestMapping(value = { "api/2.0/loginservice/status" }, method = RequestMethod.GET)
	public Object getStatus() {
		return serviceStatusConfig.getServiceStatus();

	}

}
