package com.restWebService.Server.models;

import org.springframework.stereotype.Component;

@Component
public class ServiceInternalStatus {

	private String message;

	public ServiceInternalStatus() {
		super();
	}

	public ServiceInternalStatus(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
