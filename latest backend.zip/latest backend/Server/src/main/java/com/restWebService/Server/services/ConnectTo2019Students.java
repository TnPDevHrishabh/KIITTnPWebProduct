package com.restWebService.Server.services;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class ConnectTo2019Students {

	private static final String url = "http://localhost:2000/api/phase2/1.2/authenticatestudent";
	
	public ResponseEntity<String> connectToNewStudents(String uId,String pass) {
		
		ResponseEntity<String> response = connect(uId,pass);
		return response;
	}
	private ResponseEntity<String> connect(String uId,String pass) {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.add("userId", uId);
		headers.add("password", pass);
		HttpEntity<String> request = new HttpEntity<String>(headers);
		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, request, String.class);
		return response;
	}
}
