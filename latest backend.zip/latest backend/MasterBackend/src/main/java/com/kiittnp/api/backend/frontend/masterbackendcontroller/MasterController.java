package com.kiittnp.api.backend.frontend.masterbackendcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.kiittnp.api.backend.frontend.models.TestModel;
import com.kiittnp.api.backend.frontend.services.ConnectService;
import com.kiittnp.api.backend.frontend.services.TestModelService;

@RestController
public class MasterController {
	
	private static final String loginKey = "485c0e4e-f425-4fd7-bb58-1f43ca54b673";
	private static final String noticeKey = "2bda4b6a-2d91-4ece-8a20-55296cea2d12";
	private static final String iecKey = "e28469f5-56fe-4779-964f-017a2608ed96";
	private static final String crKey = "0127d7e5-3643-436f-9581-3ada45e84b45";
	private static final String logoutKey = "77a9ccfd-2f33-4277-b774-6a150aee61be";

	@Autowired
	private ConnectService connectService;
	
	@Autowired
	private TestModelService testService;

	@CrossOrigin(maxAge = 3600)
	@RequestMapping(value = "/api/1.1/connect/login", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public Object connectToLoginService(@RequestHeader("Authorization") String authString) {
		
		return connectService.connect(authString,loginKey);
	}
	
	@CrossOrigin(maxAge = 3600)
	@RequestMapping(value = "/api/1.2/connect/notice", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public Object connectToNoticeService(@RequestHeader(value="RollNo") String roll,@RequestHeader(value="sessionId1") String userSession1,@RequestHeader(value="sessionId2") String userSession2,@RequestHeader(value="sessionId3") String userSession3,@RequestHeader(value="sessionId4") String userSession4) {
		
		return connectService.connect(roll, userSession2, userSession4,noticeKey);
	}
	
	@CrossOrigin(maxAge = 3600)
	@RequestMapping(value = "/api/1.3/connect/iec", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public Object connectToIEC() {
		
		return connectService.connect(iecKey,true);
	}
	
	@CrossOrigin(maxAge = 3600)
	@RequestMapping(value = "/api/1.4/connect/cr", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public Object connectToCR() {
		
		return connectService.connect(crKey,false);
	}
	@CrossOrigin(maxAge = 3600)
	@RequestMapping(value = "/api/1.5/connect/logout", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public Object connectToLogoutService(@RequestHeader(value = "userId") String pk) {
		
		return connectService.logout(pk,logoutKey);
	}
	
	@Deprecated
	@CrossOrigin(maxAge = 3600)
	@RequestMapping(value = "/api/test/employee", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public void storeEmployee(@RequestBody List<TestModel> testModel) {
		
		testService.insertNewEntry(testModel);
	}
}
