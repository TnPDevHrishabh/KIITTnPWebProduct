package com.kiittnp.api.backend.frontend.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

import com.kiittnp.api.backend.frontend.models.TestModel;

@Component
public interface TestRepo extends CrudRepository<TestModel,String>{
	
}
