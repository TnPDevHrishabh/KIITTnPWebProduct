package com.kiittnp.api.backend.frontend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MasterBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(MasterBackendApplication.class, args);
	}
}
