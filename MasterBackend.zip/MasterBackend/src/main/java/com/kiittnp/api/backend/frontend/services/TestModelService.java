package com.kiittnp.api.backend.frontend.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kiittnp.api.backend.frontend.models.TestModel;
import com.kiittnp.api.backend.frontend.repository.TestRepo;

@Component
public class TestModelService {

	@Autowired
	private TestRepo testRepo;
	
	public void insertNewEntry(List<TestModel> testModel) {
		
		testRepo.save(testModel);
	}
}
