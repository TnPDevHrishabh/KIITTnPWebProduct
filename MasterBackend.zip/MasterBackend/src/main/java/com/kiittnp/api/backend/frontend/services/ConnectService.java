package com.kiittnp.api.backend.frontend.services;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.kiittnp.api.backend.frontend.models.Authentication;
import com.kiittnp.api.backend.frontend.models.ServiceInternalError;

@Component
public class ConnectService {

	private static final String loginUrl = "http://localhost:8788/api/2.0/login";
	private static final String noticeUrl = "http://localhost:9000/api/2.1/notices";
	private static final String iecUrl = "http://localhost:9001/api/2.3/iec";
	private static final String crUrl = "http://localhost:9001/api/2.4/cr";
	private static final String logoutUrl = "http://localhost:7777/api/2.2/logout";

	public Object connect(String authString, String key) {

		return loginConnect(authString, key);

	}

	public Object connect(String roll, String session1, String session2, String noticeKey) {

		return noticeConnect(roll, session1, session2, noticeKey);
	}

	public Object connect(String iecKey, boolean flag) {

		return iecCrConnect(iecKey, flag);
	}
	
	public Object logout(String userId,String key) {
		
		return logoutConnect(userId,key);
	}

	private ResponseEntity<Authentication> loginConnect(String authString, String key) {

		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.add("RequestFromUI", authString);
		headers.add("MasterKey", key);
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		ResponseEntity<Authentication> response = restTemplate.exchange(loginUrl, HttpMethod.GET, entity,
				Authentication.class);
		return response;
	}

	private ResponseEntity<Object> noticeConnect(String roll, String session1, String session2, String key) {

		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.add("RequestFromUI_Session_1", session1);
		headers.add("RequestFromUI_Session_2", session2);
		headers.add("RequestFromUI_Roll", roll);
		headers.add("MasterKey", key);
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		ResponseEntity<Object> response = restTemplate.exchange(noticeUrl, HttpMethod.GET, entity, Object.class);
		return response;
	}

	private ResponseEntity<Object> iecCrConnect(String key, boolean flag) {

		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.add("MasterKey", key);
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		ResponseEntity<Object> response;
		if (flag) {
			response = restTemplate.exchange(iecUrl, HttpMethod.GET, entity, Object.class);
		} else {
			response = restTemplate.exchange(crUrl, HttpMethod.GET, entity, Object.class);
		}
		return response;
	}
	
	private ResponseEntity<ServiceInternalError> logoutConnect(String userId,String key) {

		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.add("RequestFromUI_Roll", userId);
		headers.add("MasterKey", key);
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		ResponseEntity<ServiceInternalError> response = restTemplate.exchange(logoutUrl, HttpMethod.GET, entity, ServiceInternalError.class);
		return response;
	}
}
