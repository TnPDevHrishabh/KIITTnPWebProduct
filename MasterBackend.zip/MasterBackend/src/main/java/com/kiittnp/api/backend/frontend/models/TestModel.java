package com.kiittnp.api.backend.frontend.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "test_emp_db")
public class TestModel {

	@Id
	@Column(name = "emp_id",nullable = false,unique = true,columnDefinition="VARCHAR(10)")
	private String employeeId;
	
	@Column(name = "emp_name")
	private String employeeName;
	
	@Column(name = "emp_pass")
	private String employeePass;

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeePass() {
		return employeePass;
	}

	public void setEmployeePass(String employeePass) {
		this.employeePass = employeePass;
	}
	
	
}
