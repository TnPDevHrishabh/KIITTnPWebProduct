$(document).ready(function(){
$("#login").click(function(){
var email = $("#usr").val();
var password = $("#pwd").val();
if( email =='' || password ==''){
	$("#fillCreds").css("visibility","visible");
	$("#alertDialog").css("z-index","-1");
}else {

	var payload = email+':'+password;

	$.ajax({
    url: 'http://127.0.0.1:4000/api/1.1/connect/login',
    method: 'POST',
    beforeSend: function ( xhr ) {
    	xhr.setRequestHeader('Authorization','Basic ' + btoa(payload));
    },

    success: function( data, txtStatus, xhr ){
		var check = data.status;
		if(check != "Invalid Credentials"){
			var curTime = new Date;
			var expTime = curTime.getTime() + 30*60*1000;
			curTime.setTime(expTime);
			document.cookie = "sessionCookie="+ data.sessionId1+" "+data.sessionId2+" "+data.sessionId3+" "+data.sessionId4+ " "+data.rollNo+";expires="+curTime.toUTCString;
			window.location = "./student/notice.html";

		}
		else{
			$("#alertDialog").css("visibility","visible");
			$("#alertDialog").css("z-index","10");
		}
    }

});
}
});
});
