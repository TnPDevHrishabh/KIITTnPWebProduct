$("#testButon").click(function(){
  $.getJSON("./employee.json",function(data){
    $.ajax({
      url : "http://127.0.0.1/api/test/employee",
      data : data,
      complete : function(data,txtStatus,xhr){
        console.log(xhr.status);
      }
    })
  });
});
