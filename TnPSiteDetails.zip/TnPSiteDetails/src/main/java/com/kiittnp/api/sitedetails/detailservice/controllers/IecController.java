package com.kiittnp.api.sitedetails.detailservice.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.kiittnp.api.sitedetails.detailservice.models.IecMembers;
import com.kiittnp.api.sitedetails.detailservice.services.IecRepoService;

@RestController
public class IecController {

	@Autowired
	private IecRepoService repoService;

	@CrossOrigin(maxAge = 3600)
	@RequestMapping(value = { "/api/1.0/iec" }, method = RequestMethod.GET)
	public List<IecMembers> iecListOp() {

		return repoService.retrieveList();
	}

	@RequestMapping(value = { "/api/1.0/iec" }, method = RequestMethod.POST)
	public String iecListOp(@RequestBody IecMembers iecMember) {

		return repoService.newEntry(iecMember);
	}

	@RequestMapping(value = { "/api/1.0/iec" }, method = RequestMethod.DELETE)
	public String iecListOp(@RequestHeader(value = "Key") String uniqueKey) {

		return repoService.deleteOne(uniqueKey);
	}

	@RequestMapping(value = { "/api/1.0/iec" }, method = RequestMethod.PATCH)
	public String iecListOp(@RequestBody IecMembers iecMember, @RequestHeader(value = "Id") String Id) {

		return repoService.update(iecMember, Id);
	}

}
