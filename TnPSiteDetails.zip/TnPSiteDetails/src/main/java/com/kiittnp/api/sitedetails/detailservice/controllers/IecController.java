package com.kiittnp.api.sitedetails.detailservice.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.kiittnp.api.sitedetails.detailservice.models.IecMembers;
import com.kiittnp.api.sitedetails.detailservice.models.ServiceInternalError;
import com.kiittnp.api.sitedetails.detailservice.services.IecRepoService;

@RestController
public class IecController {
	
	private static final String iecKey = "e28469f5-56fe-4779-964f-017a2608ed96";

	@Autowired
	private IecRepoService repoService;
	
	@Autowired
	private ServiceInternalError error;

	@CrossOrigin(maxAge = 3600)
	@RequestMapping(value = { "/api/2.3/iec" }, method = RequestMethod.GET)
	public Object iecListOp(@RequestHeader(value = "MasterKey") String key) {

		if(key.equals(iecKey)) {
			return repoService.retrieveList();
		}
		else {
			error = new ServiceInternalError("{Warning : Unauthorized Request}");
			return error;
		}
	}

	@Deprecated
	@RequestMapping(value = { "/api/2.3/iec" }, method = RequestMethod.POST)
	public Object iecListOp(@RequestBody IecMembers iecMember,@RequestHeader(value = "MasterKey") String key) {

		if(key.equals(iecKey)) {
			return repoService.newEntry(iecMember);
		}
		else {
			error = new ServiceInternalError("{Warning : Unauthorized Request}");
			return error;
		}
	}

	@Deprecated
	@RequestMapping(value = { "/api/2.3/iec" }, method = RequestMethod.DELETE)
	public Object iecListOp(@RequestHeader(value = "Key") String uniqueKey,@RequestHeader(value = "MasterKey") String key) {

		if(key.equals(iecKey)) {
			return repoService.deleteOne(uniqueKey);
		}
		else {
			error = new ServiceInternalError("{Warning : Unauthorized Request}");
			return error;
		}
	}

	@Deprecated
	@RequestMapping(value = { "/api/2.3/iec" }, method = RequestMethod.PATCH)
	public Object iecListOp(@RequestBody IecMembers iecMember, @RequestHeader(value = "Id") String Id,@RequestHeader(value = "MasterKey") String key) {

		if(key.equals(iecKey)) {
			return repoService.update(iecMember, Id);
		}
		else {
			error = new ServiceInternalError("{Warning : Unauthorized Request}");
			return error;
		}
	}

}
