package com.kiittnp.api.sitedetails.detailservice.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.kiittnp.api.sitedetails.detailservice.models.CompanyList;
import com.kiittnp.api.sitedetails.detailservice.services.CompanyListService;

@RestController
public class CompanyListController {

	@Autowired
	private CompanyListService repoService;

	@RequestMapping(value = { "/api/1.2/companies" }, method = RequestMethod.GET)
	public List<CompanyList> companyListOp() {

		return repoService.retrieveList();
	}

	@RequestMapping(value = { "/api/1.2/companies" }, method = RequestMethod.POST)
	public String companyListOp(@RequestBody CompanyList companyMember) {

		return repoService.newEntry(companyMember);
	}

	@RequestMapping(value = { "/api/1.2/companies" }, method = RequestMethod.DELETE)
	public String companyListOp(@RequestHeader(value = "Key") int uniqueKey) {

		return repoService.deleteOne(uniqueKey);
	}

	@RequestMapping(value = { "/api/1.2/companies" }, method = RequestMethod.PATCH)
	public String companyListOp(@RequestBody CompanyList companyMember, @RequestHeader(value = "Id") int Id) {

		return repoService.update(companyMember, Id);
	}
}
