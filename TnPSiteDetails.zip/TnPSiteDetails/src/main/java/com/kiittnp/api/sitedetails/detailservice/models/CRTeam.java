package com.kiittnp.api.sitedetails.detailservice.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "cr_team")
public class CRTeam {

	@Id
	@Column(name = "contact_no")
	private String contact;

	@Column(name = "name")
	private String name;
	
	@Column(name = "email_id")
	private String mailId;
	
	@Column(name = "designation")
	private String desig;
	
	@Column(name = "img")
	private String image;
	
	@Column(name = "css_icon")
	private String icon;
	
	@Column(name = "css_class")
	private String cssClass;
	
	@Column(name = "css_class1")
	private String cssClass1;
	
	@Column(name = "css_class2")
	private String cssClass2;
	
	@Column(name = "cr_membership")
	private String crMembership;

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public String getCssClass() {
		return cssClass;
	}

	public void setCssClass(String cssClass) {
		this.cssClass = cssClass;
	}

	public String getCssClass1() {
		return cssClass1;
	}

	public void setCssClass1(String cssClass1) {
		this.cssClass1 = cssClass1;
	}

	public String getCssClass2() {
		return cssClass2;
	}

	public void setCssClass2(String cssClass2) {
		this.cssClass2 = cssClass2;
	}

	public String getCrMembership() {
		return crMembership;
	}

	public void setCrMembership(String crMembership) {
		this.crMembership = crMembership;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public String getDesig() {
		return desig;
	}

	public void setDesig(String desig) {
		this.desig = desig;
	}
	
	
}
