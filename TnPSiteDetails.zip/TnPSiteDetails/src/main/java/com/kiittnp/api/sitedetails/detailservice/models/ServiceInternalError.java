package com.kiittnp.api.sitedetails.detailservice.models;

import org.springframework.stereotype.Component;

@Component
public class ServiceInternalError {

	private String message;

	public ServiceInternalError() {
		super();
	}

	public ServiceInternalError(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
