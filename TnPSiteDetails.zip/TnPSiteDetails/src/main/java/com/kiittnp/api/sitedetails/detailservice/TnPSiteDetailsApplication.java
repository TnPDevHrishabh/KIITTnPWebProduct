package com.kiittnp.api.sitedetails.detailservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TnPSiteDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TnPSiteDetailsApplication.class, args);
	}
}
