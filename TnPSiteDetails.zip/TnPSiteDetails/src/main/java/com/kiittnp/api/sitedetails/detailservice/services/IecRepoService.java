package com.kiittnp.api.sitedetails.detailservice.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.kiittnp.api.sitedetails.detailservice.mainrepo.IecDataRepo;
import com.kiittnp.api.sitedetails.detailservice.models.IecMembers;

@Component
public class IecRepoService {

	@Autowired
	private IecDataRepo repoObject;

	public List<IecMembers> retrieveList() {

		List<IecMembers> list = new ArrayList<>();
		for (IecMembers im : repoObject.findAll()) {
			list.add(im);
		}
		return list;
	}

	public String newEntry(@ModelAttribute IecMembers iecObject) {

		if (repoObject.findOne(iecObject.getContact()) == null) {
			repoObject.save(iecObject);
			return "Successfully created a new entry";
		} else {
			return "Already existing field";
		}
	}

	public String deleteOne(String pk) {

		IecMembers iecMembers = repoObject.findOne(pk);

		if (iecMembers != null) {
			repoObject.delete(iecMembers);
			return "Successfully deleted";
		} else {
			return "Nothing to delete";
		}
	}

	public String update(@ModelAttribute IecMembers iecList, String pk) {

		IecMembers iecMembers = repoObject.findOne(pk);

		if (iecMembers != null) {
			if (iecList.getContact() != null) {
				iecMembers.setContact(iecList.getContact());
			}
			if (iecList.getDesig() != null) {
				iecMembers.setDesig(iecList.getDesig());
			}
			if (iecList.getIos() != null) {
				iecMembers.setIos(iecList.getIos());
			}
			if (iecList.getMailId() != null) {
				iecMembers.setMailId(iecList.getMailId());
			}
			if (iecList.getName() != null) {
				iecMembers.setName(iecList.getName());
			}
			repoObject.save(iecMembers);

			return "Successfully updated";
		} else {
			return "Failed to update. Try creating a new entry";
		}

	}
}
