package com.kiittnp.api.sitedetails.detailservice.mainrepo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

import com.kiittnp.api.sitedetails.detailservice.models.IecMembers;

@Component
public interface IecDataRepo extends CrudRepository<IecMembers, String>{

}
