package com.kiittnp.api.sitedetails.detailservice.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.kiittnp.api.sitedetails.detailservice.mainrepo.CRDataRepo;
import com.kiittnp.api.sitedetails.detailservice.models.CRTeam;

@Component
public class CRRepoService {

	@Autowired
	private CRDataRepo repoObject;

	public List<CRTeam> retrieveList() {

		List<CRTeam> list = new ArrayList<>();
		for (CRTeam im : repoObject.findAll()) {
			list.add(im);
		}
		return list;
	}

	public String newEntry(@ModelAttribute CRTeam crObject) {

		if (repoObject.findOne(crObject.getContact()) == null) {
			repoObject.save(crObject);
			return "Successfully created a new entry";
		} else {
			return "Already existing field";
		}
	}

	public String deleteOne(String pk) {

		CRTeam crMembers = repoObject.findOne(pk);

		if (crMembers != null) {
			repoObject.delete(crMembers);
			return "Successfully deleted";
		} else {
			return "Nothing to delete";
		}
	}

	public String update(@ModelAttribute CRTeam crList, String pk) {

		CRTeam crMembers = repoObject.findOne(pk);

		if (crMembers != null) {
			if (crList.getContact() != null) {
				crMembers.setContact(crList.getContact());
			}
			if (crList.getDesig() != null) {
				crMembers.setDesig(crList.getDesig());
			}
			if (crList.getMailId() != null) {
				crMembers.setMailId(crList.getMailId());
			}
			if (crList.getName() != null) {
				crMembers.setName(crList.getName());
			}
			repoObject.save(crMembers);

			return "Successfully updated";
		} else {
			return "Failed to update. Try creating a new entry";
		}

	}
}
