package com.kiittnp.api.sitedetails.detailservice.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "company_list")
public class CompanyList {

	@Id
	@Column(name = "sl_no")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int serial;

	@Column(name = "company_name")
	private String name;

	public int getSerial() {
		return serial;
	}

	public void setSerial(int serial) {
		this.serial = serial;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
