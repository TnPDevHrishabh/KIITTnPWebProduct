package com.kiittnp.api.sitedetails.detailservice.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.kiittnp.api.sitedetails.detailservice.mainrepo.CompanyListRepo;
import com.kiittnp.api.sitedetails.detailservice.models.CompanyList;

@Component
public class CompanyListService {

	@Autowired
	private CompanyListRepo repoObject;

	public List<CompanyList> retrieveList() {

		List<CompanyList> list = new ArrayList<>();
		for (CompanyList im : repoObject.findAll()) {
			list.add(im);
		}
		return list;
	}

	public String newEntry(@ModelAttribute CompanyList companyObject) {

		if (repoObject.findOne(companyObject.getSerial()) == null) {
			repoObject.save(companyObject);
			return "Successfully created a new entry";
		} else {
			return "Already existing field";
		}
	}

	public String deleteOne(int pk) {

		CompanyList companyMembers = repoObject.findOne(pk);

		if (companyMembers != null) {
			repoObject.delete(companyMembers);
			return "Successfully deleted";
		} else {
			return "Nothing to delete";
		}
	}

	public String update(@ModelAttribute CompanyList companyList, int pk) {

		CompanyList companyMembers = repoObject.findOne(pk);

		if (companyMembers != null) {
			//Integer i = new Integer(companyList.getSerial());
			if (companyList.getSerial() != 0) {
				companyMembers.setSerial(companyList.getSerial());
			}
			if (companyList.getName() != null) {
				companyMembers.setName(companyList.getName());
			}
			
			repoObject.save(companyMembers);

			return "Successfully updated";
		} else {
			return "Failed to update. Try creating a new entry";
		}

	}
}
