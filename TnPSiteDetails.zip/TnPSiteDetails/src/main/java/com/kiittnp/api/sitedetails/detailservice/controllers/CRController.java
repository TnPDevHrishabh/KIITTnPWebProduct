package com.kiittnp.api.sitedetails.detailservice.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.kiittnp.api.sitedetails.detailservice.models.CRTeam;
import com.kiittnp.api.sitedetails.detailservice.models.ServiceInternalError;
import com.kiittnp.api.sitedetails.detailservice.services.CRRepoService;

@RestController
public class CRController {

	private static final String crKey = "0127d7e5-3643-436f-9581-3ada45e84b45";
	
	@Autowired
	private CRRepoService repoService;
	
	@Autowired
	private ServiceInternalError error;

	@RequestMapping(value = { "/api/2.4/cr" }, method = RequestMethod.GET)
	public Object crListOp(@RequestHeader(value = "MasterKey") String key) {

		if(key.equals(crKey)) {
		
			return repoService.retrieveList();
		}
		else {
			error = new ServiceInternalError("{Warning : Unauthorized Request}");
			return error;
		}		
	}

	@Deprecated
	@RequestMapping(value = { "/api/2.4/cr" }, method = RequestMethod.POST)
	public Object crListOp(@RequestBody CRTeam crMember,@RequestHeader(value = "MasterKey") String key) {

		if(key.equals(crKey)) {
			return repoService.newEntry(crMember);
		}
		else {
			error = new ServiceInternalError("{Warning : Unauthorized Request}");
			return error;
		}
	}

	@Deprecated
	@RequestMapping(value = { "/api/2.4/cr" }, method = RequestMethod.DELETE)
	public Object crListOp(@RequestHeader(value = "Key") String uniqueKey,@RequestHeader(value = "MasterKey") String key) {

		if(key.equals(crKey)) {
			return repoService.deleteOne(uniqueKey);
		}
		else {
			error = new ServiceInternalError("{Warning : Unauthorized Request}");
			return error;
		}
	}

	@Deprecated
	@RequestMapping(value = { "/api/2.4/cr" }, method = RequestMethod.PATCH)
	public Object crListOp(@RequestBody CRTeam crMember, @RequestHeader(value = "Id") String Id,@RequestHeader(value = "MasterKey") String key) {

		if(key.equals(crKey)) {
			return repoService.update(crMember, Id);
		}
		else {
			error = new ServiceInternalError("{Warning : Unauthorized Request}");
			return error;
		}
	}
}
