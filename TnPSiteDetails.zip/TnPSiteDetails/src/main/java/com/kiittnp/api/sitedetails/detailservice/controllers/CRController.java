package com.kiittnp.api.sitedetails.detailservice.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.kiittnp.api.sitedetails.detailservice.models.CRTeam;
import com.kiittnp.api.sitedetails.detailservice.services.CRRepoService;

@RestController
public class CRController {

	@Autowired
	private CRRepoService repoService;

	@CrossOrigin(maxAge = 3600)
	@RequestMapping(value = { "/api/1.1/cr" }, method = RequestMethod.GET)
	public List<CRTeam> crListOp() {

		return repoService.retrieveList();
	}

	@RequestMapping(value = { "/api/1.1/cr" }, method = RequestMethod.POST)
	public String crListOp(@RequestBody CRTeam crMember) {

		return repoService.newEntry(crMember);
	}

	@RequestMapping(value = { "/api/1.1/cr" }, method = RequestMethod.DELETE)
	public String crListOp(@RequestHeader(value = "Key") String uniqueKey) {

		return repoService.deleteOne(uniqueKey);
	}

	@RequestMapping(value = { "/api/1.1/cr" }, method = RequestMethod.PATCH)
	public String crListOp(@RequestBody CRTeam crMember, @RequestHeader(value = "Id") String Id) {

		return repoService.update(crMember, Id);
	}
}
